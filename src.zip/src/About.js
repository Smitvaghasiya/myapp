const About = (props)=>{
    return (
        <>
            <h3>this is About </h3>
        </>
    );
}

export default About;