const Footer = (props)=>{
    return (
        <h2>Footer</h2>
    );
}

export {Footer};