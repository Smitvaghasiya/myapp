const Home = (props)=>{
    return (
        <h3>This is Home</h3>
    );
}

export {Home};