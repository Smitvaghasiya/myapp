const Contact = (props)=>{
    return (
        <h3>This is Contact</h3>
    );
}

export {Contact};